// must have game loop

package com.game.src.main;

import java.awt.*; // IMPORT ALL AWT LIBRARIES
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;

public class Base  extends Canvas implements Runnable{ //extends canvas component from the awt and implements the runnable method
	
	private static final long serialVersionUID = 1L;

	public static final int width = 960;
	public static final int height = 540; // we use static becoz it wont change
	public static final int scale = 1;
	public final String title = "Jumping bean"; //our game title
	private mainMenu  menu; // FOR THE HOMESCREEN MENU THAT WELCOMES YOU TO INNER MENU
	private boolean running = false;
	private Thread thread;	
	//buffered image
	private BufferedImage image = new BufferedImage (width,height,BufferedImage.TYPE_INT_RGB); //buffers our whole window. needs width and height and we access the rgb
	//private BufferedImage spriteSheet = null;
	private BufferedImage background = null;
	//loop
					
	
	public void init () {
		BufferedImageLoader loader = new BufferedImageLoader();
		try {
			//spriteSheet = loader.loadImage(path)
			background = loader.loadImage("/bean.png");
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}
	//start
	private synchronized void start () { //starts up our initialized thread
		if (running)
			return; // if running is already true then return out of this method as we dont need to be here anymore
		running = true;
		thread = new Thread (this);// refers to this RUN method were talking about 
		thread.start();//starts the thread which is using the run method
	}
	
                   //	MUST CREATE THREAD
	//stop
	private synchronized void stop() {
		if (!running)  // if there isnt a thread going on then no need to do this method
			return;
		
		running = false ; // stops our game loop
		try {
			thread.join(); // joining all the threads together
		} catch (InterruptedException e) {   // we surround with try and catch because it can actually not work
			// TODO Auto-generated catch block
			e.printStackTrace(); // tells us in console we have error
		}
	}
	public void run () {
		//calling init so that we display bg
		
		init();
		//below we get the fps using the currrent timer we also get the ticks
		long lastTime = System.nanoTime(); // returns current timesoruce in nano seconds we use long as it can store higher pos/neg numbers
		final double amountOfticks = 60.0; // updates  60 time (fps)
		double nano =1000000000 / amountOfticks;
		double delta = 0; // calculates the time passed. if tciks are running abit behind it catches up
		int updates = 0;
		int frames = 0;
		long timer = System.currentTimeMillis(); //current time in ms
		while (running) {	
			//game loop
			long now = System.nanoTime(); // from last time to now . small difference
			// get difference from lasttime to now
			delta += (now - lastTime) / nano;
			lastTime = now; // sets our last time to  what our time is now
			if (delta >=1) {
				tick();
				updates++;
				delta--;
			}
			render();
			frames ++;
			
			if (System.currentTimeMillis() - timer > 1000) {
				timer +=1000; // we dont want it to loop through again
				System.out.println(updates + "Ticks, Fps" + frames);
				updates = 0;
				frames = 0;
			}
		}	
		
		stop(); //after our  game loop is done is complete then we stop
	}
	
	//EVERYTHING IN THE GAME THAT UPDATES
 	private void tick() {
		// TODO Auto-generated method stub
		
	}
 	
 	//EVERYTHING IN THE GAME THAT RENDERS
 	private void render() {
   /*b.strat works in the background*/
 		BufferStrategy bs = this.getBufferStrategy(); // 'this'  access this from our canvas class which we inherit
 		// getbuffersrtategy() returns a b.s used by 'this' and retuns null if no b.s created
 		
 		if(bs == null) {
 			createBufferStrategy(3); //3 means we are going to have 3 buffers
 			return;
 		}
 		
 		Graphics g = bs.getDrawGraphics(); // creates a graphics context for drawing buffers// draws out our buffers
 		//drawing the bg //base class
 		
 		//g.drawImage(image,0,0,getWidth(),getHeight(),this);
 		//g.setColor(Color.blue);
 		//g.fillRect(1, 0, 1600, 600);
 		
 		g.drawImage(background,0,0,null);
 		////////////////////////////////
 		
 		g.dispose(); // must dispose it as next time it loops around it will be null
 		bs.show();
 	}

	public static void main(String[] args) {
	  Base firstBase = new Base ();	// an instance for our base class
	  
	  // setting our  preferred sizes
	  firstBase.setPreferredSize(new Dimension (width * scale, height * scale));
	  firstBase.setMaximumSize(new Dimension (width * scale, height * scale));
	  firstBase.setMinimumSize(new Dimension (width * scale, height * scale));

	// setting up the frame for our game and adding in the dimensions
	  JFrame jframe = new JFrame(firstBase.title); 
	  jframe.add(firstBase);
	  jframe.pack(); // packs everything together in window
	  jframe.setDefaultCloseOperation(jframe.EXIT_ON_CLOSE);// takes an integer . allows our red x to work
	  jframe.setResizable(false);// prevemnts resizing of dimensions
	  jframe.setLocationRelativeTo(null); // sets location relative to default position meaning it wont change 
	  jframe.setVisible(true); // allows us to see the frame and its contents
	  
	  // we must start the game in main
	  firstBase.start();
 	}
}


//LEARN:
//encapsulation
//Polymorphism
//interface stuff
///BUFFERED IMAGE STUFF
//TRY CATCH
// AWT IMPORT!!!
// BUFFER STUFF
