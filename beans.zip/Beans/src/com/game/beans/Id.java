package com.game.beans;

//to check for coalition detection etc
public enum Id {
	player,wall;
}
