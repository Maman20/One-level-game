package com.game.beans.graphics;

import java.awt.image.BufferedImage;

public class Sprite {
	
	public SpriteSheet sheet;
	public BufferedImage image;
	
	public Sprite(SpriteSheet sheet , int x ,int y)
	{
		image = sheet.getSprite(x, y);
	}

	//get bufferedimage as a sprite then render that
	public BufferedImage getBufferedImage()
	{
		return image;
	}
}
