package com.game.beans.tile;

import java.awt.Color;
import java.awt.Graphics;

import com.game.beans.Game;
import com.game.beans.Handler;
import com.game.beans.Id;

public class Wall extends Tile{

	public Wall(int x, int y, int width, int height, boolean solid, Id wall, Handler handler) {
		super(x, y, width, height, solid, handler);

	}


	public void render(Graphics g) {
		g.drawImage(Game.grass.getBufferedImage(), x,y,width ,height, null);
	}

	@Override
	public void tick() {
		
		
	}

}
