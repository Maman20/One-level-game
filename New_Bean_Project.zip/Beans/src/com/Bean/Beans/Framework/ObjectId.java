package com.Bean.Beans.Framework;

public enum ObjectId {  //library to hold all of the objects in our game

	Player(),
	Block(); // our objects
}
