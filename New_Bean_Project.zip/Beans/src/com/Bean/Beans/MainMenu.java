package com.Bean.Beans;

public class MainMenu {

}
