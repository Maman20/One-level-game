package com.Bean.Beans;
//access with time
//play screen recorded video gif until user presses enter to rejoin game buffer
public class Simulation {

}
