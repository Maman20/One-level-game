package com.Bean.Beans;

//text animatioN
public class Credits {

}
